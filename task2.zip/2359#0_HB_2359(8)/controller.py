#!/usr/bin/env python3

'''
*****************************************************************************************
*
*        		===============================================
*           		    HolA Bot (HB) Theme (eYRC 2022-23)
*        		===============================================
*
*  This script should be used to implement Task 0 of HolA Bot (HB) Theme (eYRC 2022-23).
*
*  This software is made available on an "AS IS WHERE IS BASIS".
*  Licensee/end user indemnifies and will keep e-Yantra indemnified from
*  any and all claim(s) that emanate from the use of the Software or
*  breach of the terms of this agreement.
*
*****************************************************************************************
'''

# Team ID:		[  HB_2359 ]
# Author List:		[ Sriram Thangavel R, Akshith S, Sree Harish R S, Prasannakumar N ]
# Filename:		controller.py
# Functions:
#			[ inverse_kinematicse, aruco_feedback_Cb, signal_handler]
# Nodes:		/right_wheel_force, /left_wheel_force, /front_wheel_force, detected_aruco, task2_goals


################### IMPORT MODULES #######################

import rospy
import signal		# To handle Signals by OS/user
import sys		# To handle Signals by OS/user

from geometry_msgs.msg import Wrench		# Message type used for publishing force vectors
from geometry_msgs.msg import PoseArray	# Message type used for receiving goals
from geometry_msgs.msg import Pose2D		# Message type used for receiving feedback

import time
import math		# If you find it useful

from tf.transformations import euler_from_quaternion	# Convert angles

################## GLOBAL VARIABLES ######################

PI = 3.14

x_goals = [50,350,50,250,250]
y_goals = [350,50,50,350,50]
theta_goals = [0, 0, 0, 0, 0]

right_wheel_pub = None
left_wheel_pub = None
front_wheel_pub = None

#positions and orientation
hola_x = 0
hola_y = 0
hola_theta = 0

#distance from the center to the wheel
d =  0.17483


front_wheel = Wrench()
right_wheel = Wrench()
left_wheel = Wrench()

#wheel angle 
wheel_angle = PI/3

#kp values
kp_x = 4.5
kp_y = 4.5
kp_z = 45
##################### FUNCTION DEFINITIONS #######################



def signal_handler(sig, frame):
	print('Clean-up !')
	cleanup()
	sys.exit(0)

def cleanup():
	pass
	
  
  
def task2_goals_Cb(msg):
	global x_goals, y_goals, theta_goals
	x_goals.clear()
	y_goals.clear()
	theta_goals.clear()

	for waypoint_pose in msg.poses:
		x_goals.append(waypoint_pose.position.x)
		y_goals.append(waypoint_pose.position.y)

		orientation_q = waypoint_pose.orientation
		orientation_list = [orientation_q.x, orientation_q.y, orientation_q.z, orientation_q.w]
		theta_goal = euler_from_quaternion (orientation_list)[2]
		theta_goals.append(theta_goal)

def aruco_feedback_Cb(msg):
	global hola_x,hola_y,hola_theta
	hola_x = msg.x
	hola_y = msg.y
	hola_theta = msg.theta



def inverse_kinematics(vel_x,vel_y,vel_z):
	vel_front_wheel = -d*vel_z + vel_x
	vel_right_wheel = -d*vel_z - math.cos(wheel_angle)*vel_x - math.sin(wheel_angle)*vel_y
	vel_left_wheel = -d*vel_z - math.cos(wheel_angle)*vel_x + math.sin(wheel_angle)*vel_y

	front_wheel.force.x = vel_front_wheel
	right_wheel.force.x = vel_right_wheel
	left_wheel.force.x = vel_left_wheel



def main():

	rospy.init_node('controller_node')

	signal.signal(signal.SIGINT, signal_handler)

	right_wheel_pub = rospy.Publisher('/right_wheel_force', Wrench, queue_size=10)
	front_wheel_pub = rospy.Publisher('/front_wheel_force', Wrench, queue_size=10)
	left_wheel_pub = rospy.Publisher('/left_wheel_force', Wrench, queue_size=10)

	rospy.Subscriber('detected_aruco',Pose2D,aruco_feedback_Cb)
	rospy.Subscriber('task2_goals',PoseArray,task2_goals_Cb)
	
	rate = rospy.Rate(100)   

	index = 0
	while not rospy.is_shutdown():
		
		# Error in global frame
		error_g_x = x_goals[index] - hola_x
		error_g_y = y_goals[index] - hola_y
		error_g_theta = theta_goals[index] - hola_theta

		#Error in body frame
		error_b_x = error_g_x*math.cos(hola_theta) + error_g_y*math.sin(hola_theta)
		error_b_y = -error_g_x*math.sin(hola_theta) + error_g_y*math.cos(hola_theta)
		error_b_theta = error_g_theta


		#velocity from calculated error
		vel_x = kp_x * error_b_x
		vel_y = kp_y * error_b_y
		vel_z = kp_z * error_b_theta
		
		#force vectors for individual wheels from it.(Inverse Kinematics)
		inverse_kinematics(vel_x,vel_y,vel_z)


		# publishing forces
		front_wheel_pub.publish(front_wheel)
		right_wheel_pub.publish(right_wheel)
		left_wheel_pub.publish(left_wheel)
		
		# position and orientation conditions
		x_condition_p = x_goals[index]-0.05 <= hola_x <= x_goals[index]+0.05
		y_condition_p = y_goals[index]-0.05 <= hola_y <= y_goals[index]+0.05
		theta_condition_p = theta_goals[index] - 0.05 <= hola_theta <= theta_goals[index] + 0.05

		if x_condition_p:
			vel_x = 0
			inverse_kinematics(0,vel_y,vel_z)
			
		
		if y_condition_p:
			vel_y = 0
			inverse_kinematics(vel_x,0,vel_z)
			
		
		if theta_condition_p:
			vel_z = 0
			inverse_kinematics(vel_x,vel_y,0)

			
			

		if x_condition_p and y_condition_p  and theta_condition_p:
			inverse_kinematics(0,0,0)
			print("Goal reached !!!!")
			rospy.sleep(1)

			if index < len(x_goals)-1:
				index += 1

		rate.sleep()

    ############################################

if __name__ == "__main__":
	try:
		main()
	except rospy.ROSInterruptException:
		pass

