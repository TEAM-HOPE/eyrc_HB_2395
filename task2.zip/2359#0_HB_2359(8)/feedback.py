#!/usr/bin/env python3

'''
*****************************************************************************************
*
*        		===============================================
*           		    HolA Bot (HB) Theme (eYRC 2022-23)
*        		===============================================
*
*  This script should be used to implement Task 2 of HolA Bot (HB) Theme (eYRC 2022-23).
*
*  This software is made available on an "AS IS WHERE IS BASIS".
*  Licensee/end user indemnifies and will keep e-Yantra indemnified from
*  any and all claim(s) that emanate from the use of the Software or
*  breach of the terms of this agreement.
*
*****************************************************************************************
'''

# Team ID:		[ HB_2359 ]
# Author List:		[Sriram Thangavel R, Akshith S, Sree Harish R S, Prasannakumar N]
# Filename:		feedback.py
# Functions:
#			[ detect_aruco_marker, aruco_centroid, aruco_orientation, callback, main ]
# Nodes:		detected_aruco overhead_cam/image_raw


######################## IMPORT MODULES ##########################
			
import rospy 				
from sensor_msgs.msg import Image 	# Image is the message type for images in ROS
from cv_bridge import CvBridge	# Package to convert between ROS and OpenCV Images
import cv2				# OpenCV Library
import math				
from geometry_msgs.msg import Pose2D	# Required to publish ARUCO's detected position & orientation

############################ GLOBALS #############################

aruco_publisher = rospy.Publisher('detected_aruco', Pose2D)
aruco_msg = Pose2D()

##################### FUNCTION DEFINITIONS #######################

#To detect aruco
def detect_aruco_marker(current_frame):
	aruco_dict = cv2.aruco.Dictionary_get(cv2.aruco.DICT_4X4_250)
	aruco_parameters = cv2.aruco.DetectorParameters_create()
	corners , ids, rejected_imgpoints = cv2.aruco.detectMarkers(current_frame,aruco_dict,parameters = aruco_parameters)
	return corners


#To find aruco centroid
def aruco_centroid(corner_array):
	corner_array = corner_array
	M = cv2.moments(corner_array)
	cx = M["m10"] / M["m00"]
	cy = M["m01"] / M["m00"]
	return cx , 500 - cy

#To find aruco orientation
def aruco_orientation(corners,cx,cy):
	mid_x = (corners[0][0][1][0]+ corners[0][0][2][0])/2
	mid_y = ((500 - corners[0][0][1][1])+ (500 - corners[0][0][2][1]))/2
	del_x = mid_x - cx
	del_y = mid_y - cy
	theta = math.atan2(del_y,del_x)
	return round(theta,3)



def callback(data):
	# Bridge is Used to Convert ROS Image message to OpenCV image
	br = CvBridge()
	rospy.loginfo("receiving camera frame")
	get_frame = br.imgmsg_to_cv2(data, "mono8")		# Receiving raw image in a "grayscale" format
	current_frame = cv2.resize(get_frame, (500, 500), interpolation = cv2.INTER_LINEAR)

	corners = detect_aruco_marker(current_frame)
	centroid_x , centroid_y = aruco_centroid(corners[0][0])
	theta = aruco_orientation(corners,centroid_x,centroid_y)

	aruco_msg.x = centroid_x
	aruco_msg.y = centroid_y
	aruco_msg.theta = theta
	aruco_publisher.publish(aruco_msg)

      
def main():
	rospy.init_node('aruco_feedback_node')  
	rospy.Subscriber('overhead_cam/image_raw', Image, callback)
	rospy.spin()
  
if __name__ == '__main__':
  main()
